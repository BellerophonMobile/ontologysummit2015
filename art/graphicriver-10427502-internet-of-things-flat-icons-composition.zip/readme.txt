Used font – 
http://www.fontsquirrel.com/fonts/fira-sans
